"use client"

import  from "../public/js/main"

export default function SyntheticV0PageForDeployment() {
  return < />
}