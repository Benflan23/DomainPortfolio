// Global variables
const currentEditingDomain = null

// Theme Management
function toggleTheme() {
  const currentTheme = document.documentElement.getAttribute("data-theme")
  const newTheme = currentTheme === "dark" ? "light" : "dark"

  document.documentElement.setAttribute("data-theme", newTheme)
  localStorage.setItem("theme", newTheme)

  // Update toggle button
  const themeIcon = document.getElementById("theme-icon")
  const themeText = document.getElementById("theme-text")
  const darkModeToggle = document.getElementById("darkModeToggle")

  if (newTheme === "dark") {
    if (themeIcon) themeIcon.className = "fas fa-sun"
    if (themeText) themeText.textContent = "Light Mode"
    if (darkModeToggle) darkModeToggle.checked = true
  } else {
    if (themeIcon) themeIcon.className = "fas fa-moon"
    if (themeText) themeText.textContent = "Dark Mode"
    if (darkModeToggle) darkModeToggle.checked = false
  }
}

// Initialize theme on page load
document.addEventListener("DOMContentLoaded", () => {
  const savedTheme = localStorage.getItem("theme") || "light"
  document.documentElement.setAttribute("data-theme", savedTheme)

  const darkModeToggle = document.getElementById("darkModeToggle")
  if (darkModeToggle) {
    darkModeToggle.checked = savedTheme === "dark"
  }

  // Update theme button text
  const themeIcon = document.getElementById("theme-icon")
  const themeText = document.getElementById("theme-text")
  if (savedTheme === "dark") {
    if (themeIcon) themeIcon.className = "fas fa-sun"
    if (themeText) themeText.textContent = "Light Mode"
  }

  // Set today's date as default for date inputs
  const today = new Date().toISOString().split("T")[0]
  const dateInputs = document.querySelectorAll('input[type="date"]')
  dateInputs.forEach((input) => {
    if (!input.value) {
      input.value = today
    }
  })
})

// Toggle sidebar for mobile
function toggleSidebar() {
  const sidebar = document.querySelector(".sidebar")
  sidebar.classList.toggle("active")
}

// Domain Management Functions
function openDomainModal(domainId = null) {
  const modal = document.getElementById("domainModal")
  const form = document.getElementById("domainForm")
  const title = document.getElementById("modalTitle")

  if (domainId && window.domainsData) {
    // Edit mode
    const domain = window.domainsData.find((d) => d.id === domainId)
    if (domain) {
      title.innerHTML = '<i class="fas fa-edit"></i> Edit Domain'
      document.getElementById("domainId").value = domain.id
      document.getElementById("domainName").value = domain.name
      document.getElementById("registrar").value = domain.registrar
      document.getElementById("category").value = domain.category
      document.getElementById("purchaseDate").value = domain.purchaseDate
      document.getElementById("purchasePrice").value = domain.purchasePrice
      document.getElementById("status").value = domain.status
    }
  } else {
    // Add mode
    title.innerHTML = '<i class="fas fa-plus"></i> Add Domain'
    form.reset()
    document.getElementById("domainId").value = ""
    // Set today's date as default
    const today = new Date().toISOString().split("T")[0]
    document.getElementById("purchaseDate").value = today
  }

  modal.style.display = "block"
}

function closeDomainModal() {
  document.getElementById("domainModal").style.display = "none"
}

function editDomain(domainId) {
  openDomainModal(domainId)
}

async function deleteDomain(domainId) {
  if (confirm("Are you sure you want to delete this domain? This action cannot be undone.")) {
    try {
      const response = await fetch(`/api/domains/${domainId}`, {
        method: "DELETE",
      })

      if (response.ok) {
        showNotification("Domain deleted successfully!", "success")
        setTimeout(() => location.reload(), 1000)
      } else {
        showNotification("Error deleting domain", "error")
      }
    } catch (error) {
      console.error("Error:", error)
      showNotification("Error deleting domain", "error")
    }
  }
}

// Bulk Add Functions
function openBulkAddModal() {
  document.getElementById("bulkAddModal").style.display = "block"
}

function closeBulkAddModal() {
  document.getElementById("bulkAddModal").style.display = "none"
}

async function processBulkAdd(bulkData) {
  const lines = bulkData.trim().split("\n")
  const domains = []
  const errors = []

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim()
    if (!line || line.startsWith("#")) continue

    const parts = line.split(",").map((part) => part.trim())
    if (parts.length >= 5) {
      // Validate domain name
      if (!parts[0].includes(".")) {
        errors.push(`Line ${i + 1}: Invalid domain name "${parts[0]}"`)
        continue
      }

      // Validate date format
      const dateRegex = /^\d{4}-\d{2}-\d{2}$/
      if (!dateRegex.test(parts[3])) {
        errors.push(`Line ${i + 1}: Invalid date format "${parts[3]}" (use YYYY-MM-DD)`)
        continue
      }

      // Validate price
      const price = Number.parseFloat(parts[4])
      if (isNaN(price) || price < 0) {
        errors.push(`Line ${i + 1}: Invalid price "${parts[4]}"`)
        continue
      }

      domains.push({
        name: parts[0].toLowerCase(),
        registrar: parts[1] || "Unknown",
        category: parts[2] || "Other",
        purchaseDate: parts[3],
        purchasePrice: price,
        status: parts[5] || "Active",
      })
    } else if (parts[0]) {
      errors.push(`Line ${i + 1}: Incomplete data (need at least 5 columns)`)
    }
  }

  if (errors.length > 0) {
    const showErrors = confirm(
      `Found ${errors.length} error(s):\n\n${errors.slice(0, 3).join("\n")}${errors.length > 3 ? "\n... and more" : ""}\n\nImport ${domains.length} valid domains and skip errors?`,
    )
    if (!showErrors) return
  }

  if (domains.length === 0) {
    showNotification("No valid domains found in the data", "error")
    return
  }

  try {
    const response = await fetch("/api/domains/bulk", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ domains }),
    })

    if (response.ok) {
      closeBulkAddModal()
      showNotification(`Successfully imported ${domains.length} domains!`, "success")
      setTimeout(() => location.reload(), 1500)
    } else {
      showNotification("Error importing domains", "error")
    }
  } catch (error) {
    console.error("Error:", error)
    showNotification("Error importing domains", "error")
  }
}

// Import/Export Functions
function downloadTemplate() {
  const headers = ["Domain Name", "Registrar", "Category", "Purchase Date", "Purchase Price", "Status"]
  const exampleData = [
    "example1.com,GoDaddy,Tech,2023-01-15,12.99,Active",
    "example2.com,Namecheap,Business,2023-02-01,15.99,For Sale",
    "example3.com,Cloudflare,E-commerce,2023-03-10,25.00,Active",
  ]

  const csvContent = [
    headers.join(","),
    "# Instructions: Fill in your domain data below this line",
    "# Format: Domain Name, Registrar, Category, Purchase Date (YYYY-MM-DD), Purchase Price, Status",
    "# Status options: Active, For Sale, Sold, Expired",
    "# Delete these instruction lines before importing",
    "",
    ...exampleData,
  ].join("\n")

  downloadFile(csvContent, "domains_import_template.csv", "text/csv")

  showNotification("Template downloaded! Check your Downloads folder.", "success")
}

function importDomains(event) {
  const file = event.target.files[0]
  if (!file) return

  const fileName = file.name.toLowerCase()

  if (fileName.endsWith(".csv")) {
    importCSV(file)
  } else if (fileName.endsWith(".xlsx") || fileName.endsWith(".xls")) {
    showNotification("Excel files not directly supported. Please save as CSV format first.", "warning")
    event.target.value = ""
  } else {
    showNotification("Please select a CSV file (.csv format)", "error")
    event.target.value = ""
  }
}

function importCSV(file) {
  const reader = new FileReader()
  reader.onload = (e) => {
    const csv = e.target.result
    const lines = csv
      .split("\n")
      .filter((line) => line.trim() && !line.startsWith("#") && !line.toLowerCase().includes("domain name"))

    let startIndex = 0
    if (lines[0] && lines[0].toLowerCase().includes("domain")) {
      startIndex = 1
    }

    const domains = []
    const errors = []

    for (let i = startIndex; i < lines.length; i++) {
      const values = lines[i].split(",").map((v) => v.trim())

      if (values.length >= 5 && values[0]) {
        if (!values[0].includes(".")) {
          errors.push(`Line ${i + 1}: Invalid domain name "${values[0]}"`)
          continue
        }

        const dateRegex = /^\d{4}-\d{2}-\d{2}$/
        if (!dateRegex.test(values[3])) {
          errors.push(`Line ${i + 1}: Invalid date format "${values[3]}" (use YYYY-MM-DD)`)
          continue
        }

        const price = Number.parseFloat(values[4])
        if (isNaN(price) || price < 0) {
          errors.push(`Line ${i + 1}: Invalid price "${values[4]}"`)
          continue
        }

        domains.push({
          name: values[0].toLowerCase(),
          registrar: values[1] || "Unknown",
          category: values[2] || "Other",
          purchaseDate: values[3],
          purchasePrice: price,
          status: values[5] || "Active",
        })
      } else if (values[0]) {
        errors.push(`Line ${i + 1}: Incomplete data`)
      }
    }

    if (errors.length > 0) {
      const showErrors = confirm(`Found ${errors.length} error(s). Import ${domains.length} valid domains anyway?`)
      if (!showErrors) return
    }

    if (domains.length === 0) {
      showNotification("No valid domains found in the file", "error")
      return
    }

    fetch("/api/domains/bulk", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ domains }),
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.success) {
          showNotification(`Successfully imported ${domains.length} domains!`, "success")
          setTimeout(() => location.reload(), 1500)
        } else {
          showNotification("Error importing domains", "error")
        }
      })
      .catch((error) => {
        console.error("Error:", error)
        showNotification("Error importing domains", "error")
      })
  }

  reader.readAsText(file)
}

function exportDomains() {
  if (!window.domainsData || window.domainsData.length === 0) {
    showNotification("No domains to export", "warning")
    return
  }

  const headers = [
    "Domain Name",
    "Registrar",
    "Category",
    "Purchase Date",
    "Purchase Price",
    "Status",
    "Expiration Date",
    "Latest Evaluation",
  ]

  const csvContent = [
    headers.join(","),
    ...window.domainsData.map((domain) => {
      const latestEval =
        domain.evaluations && domain.evaluations.length > 0
          ? domain.evaluations[domain.evaluations.length - 1].value
          : ""

      return [
        domain.name,
        domain.registrar,
        domain.category,
        domain.purchaseDate,
        domain.purchasePrice,
        domain.status,
        domain.expirationDate,
        latestEval,
      ].join(",")
    }),
  ].join("\n")

  const fileName = `domains_export_${new Date().toISOString().split("T")[0]}.csv`
  downloadFile(csvContent, fileName, "text/csv")

  showNotification(`Exported ${window.domainsData.length} domains successfully!`, "success")
}

// Sales Management Functions
function openSaleModal() {
  document.getElementById("saleModal").style.display = "block"
  // Set today's date as default
  const today = new Date().toISOString().split("T")[0]
  document.getElementById("saleDate").value = today
}

function closeSaleModal() {
  document.getElementById("saleModal").style.display = "none"
}

function exportSales(format) {
  if (format === "csv") {
    exportSalesToCSV()
  }
}

function exportSalesToCSV() {
  const headers = ["Domain Name", "Sale Date", "Sale Price", "Buyer", "Purchase Price", "Profit/Loss"]
  const csvContent = [
    headers.join(","),
    // This would use actual sales data from the page
    "example-domain.com,2023-06-15,500.00,John Doe,12.99,487.01",
  ].join("\n")

  downloadFile(csvContent, "sales_history.csv", "text/csv")
  showNotification("Sales data exported successfully!", "success")
}

// Settings Functions
async function addSetting(type, inputId) {
  const input = document.getElementById(inputId)
  const value = input.value.trim()

  if (value) {
    try {
      const response = await fetch("/api/settings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ type, value }),
      })

      if (response.ok) {
        showNotification("Setting added successfully!", "success")
        setTimeout(() => location.reload(), 1000)
      } else {
        showNotification("Error adding setting", "error")
      }
    } catch (error) {
      console.error("Error:", error)
      showNotification("Error adding setting", "error")
    }
  }
}

async function removeItem(type, value) {
  if (confirm(`Are you sure you want to remove "${value}"?`)) {
    try {
      const response = await fetch("/api/settings/remove", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ type, value }),
      })

      if (response.ok) {
        showNotification("Item removed successfully!", "success")
        setTimeout(() => location.reload(), 1000)
      } else {
        showNotification("Error removing item", "error")
      }
    } catch (error) {
      console.error("Error:", error)
      showNotification("Error removing item", "error")
    }
  }
}

// Utility Functions
function downloadFile(content, fileName, mimeType) {
  const blob = new Blob([content], { type: `${mimeType};charset=utf-8;` })
  const url = window.URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = fileName
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  window.URL.revokeObjectURL(url)
}

function showNotification(message, type = "info") {
  // Create notification element
  const notification = document.createElement("div")
  notification.className = `notification notification-${type}`
  notification.innerHTML = `
    <div class="notification-content">
      <i class="fas fa-${getNotificationIcon(type)}"></i>
      <span>${message}</span>
    </div>
  `

  // Add styles
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 9999;
    padding: 15px 20px;
    border-radius: 8px;
    color: white;
    font-weight: 500;
    box-shadow: 0 4px 20px rgba(0,0,0,0.3);
    transform: translateX(400px);
    transition: transform 0.3s ease;
    max-width: 400px;
    background: ${getNotificationColor(type)};
  `

  document.body.appendChild(notification)

  // Animate in
  setTimeout(() => {
    notification.style.transform = "translateX(0)"
  }, 100)

  // Remove after delay
  setTimeout(() => {
    notification.style.transform = "translateX(400px)"
    setTimeout(() => {
      if (notification.parentNode) {
        notification.parentNode.removeChild(notification)
      }
    }, 300)
  }, 4000)
}

function getNotificationIcon(type) {
  switch (type) {
    case "success":
      return "check-circle"
    case "error":
      return "exclamation-circle"
    case "warning":
      return "exclamation-triangle"
    default:
      return "info-circle"
  }
}

function getNotificationColor(type) {
  switch (type) {
    case "success":
      return "#28a745"
    case "error":
      return "#dc3545"
    case "warning":
      return "#ffc107"
    default:
      return "#17a2b8"
  }
}

function formatCurrency(amount) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(amount)
}

function formatDate(dateString) {
  return new Date(dateString).toLocaleDateString()
}

// Form Handlers
document.addEventListener("DOMContentLoaded", () => {
  // Domain Form Handler
  const domainForm = document.getElementById("domainForm")
  if (domainForm) {
    domainForm.addEventListener("submit", async (e) => {
      e.preventDefault()

      const formData = new FormData(domainForm)
      const data = Object.fromEntries(formData.entries())
      const domainId = document.getElementById("domainId").value

      try {
        const url = domainId ? `/api/domains/${domainId}` : "/api/domains"
        const method = domainId ? "PUT" : "POST"

        const response = await fetch(url, {
          method: method,
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        })

        if (response.ok) {
          closeDomainModal()
          showNotification(
            domainId ? "Domain updated successfully!" : "Domain added successfully!",
            "success"
          )
          setTimeout(() => location.reload(), 1000)
        } else {
          showNotification("Error saving domain", "error")
        }
      } catch (error\
